package com.company;

import java.util.Random;
import java.util.Scanner;

//Abdullah Shahid

public class Main {



    public static void main(String[] args) {
        // doing to input part first
        Scanner scnr = new Scanner(System.in);
        System.out.println("Please enter your first name: ");
        String first_name = scnr.nextLine();
        System.out.println("Please enter your last name: ");
        String last_name = scnr.nextLine();
        System.out.println("Please enter your middle Initial: ");
        String M_I = scnr.nextLine(); // middle name (MI)
        System.out.println("Please enter your 2-digits favorite number: ");
        String f_n = scnr.nextLine();
        System.out.println("Please enter your City of Birth: ");
        String city = scnr.nextLine();
        System.out.println("Please enter your favorite color: ");
        String color = scnr.nextLine();
        // program to make 2 rand digits
        Random random = new Random();
        int random_digit = random.nextInt(99); // this will only get 2 digits excludes 100
        System.out.println("Your 2-digits random number: " + random_digit);
        System.out.println("Your full name in the correct formal is: " + first_name.substring(0,1).toUpperCase() +first_name.substring(1).toLowerCase() + " " + M_I.substring(0,1).toUpperCase() + ". " + last_name.substring(0,1) + last_name.substring(1).toLowerCase());
        System.out.println("Your email at Guilford in the correct format is: " + last_name.toLowerCase() + first_name.substring(0,1).toLowerCase() + M_I.substring(0,1).toLowerCase() + "@guilford.edu");
        // final password
        String password  =  first_name.substring(0,1).toUpperCase() + first_name.substring(1,2).toLowerCase()+last_name.substring(0,1).toUpperCase() + last_name.substring(1,2).toLowerCase() + f_n.substring(0,1) + "^" + f_n.substring(1) + city.substring(0,1).toUpperCase()+city.substring(1,2).toLowerCase()+color.substring(0,1).toUpperCase()+color.substring(1,2).toLowerCase()+random_digit;
        System.out.println(first_name.substring(0,1).toUpperCase() + first_name.substring(1,2).toLowerCase()+last_name.substring(0,1).toUpperCase() + last_name.substring(1,2).toLowerCase() + f_n.substring(0,1) + "^" + f_n.substring(1) + city.substring(0,1).toUpperCase()+city.substring(1,2).toLowerCase()+color.substring(0,1).toUpperCase()+color.substring(1,2).toLowerCase()+random_digit);
        // password encryption

        final String secretKey = "ThisIsSecretKey";
        String encryptedString = AES.encrypt(password, secretKey) ;
        String decryptedString = AES.decrypt(encryptedString, secretKey) ;
        System.out.println("Your password encrypted using AES and secret key (ThisIsSecretKey) is:");
        System.out.println(encryptedString);
        System.out.println("Your password decrypted using AES and secret key (ThisIsSecretKey) is:");
        System.out.println(decryptedString);
        System.out.println( );
        System.out.println( );
        System.out.println("Here's some sayings about passwords:");
        System.out.println("Choosing a hard-to-guess, but easy-to-remember password is important!");
        System.out.println( );
        System.out.println( );
        System.out.println("Treat your password like your toothbrush.");
        System.out.println("Don't let anybody else use it, and get a new one every six months.");







    }
}
