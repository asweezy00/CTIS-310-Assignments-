package com.company;
//Abdullah Shahid

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

public class Calendar {
    public static int day(int month, int day, int year) {
        int y = year - (14 - month) / 12;
        int x = y + y / 4 - y / 100 + y / 400;
        int m = month + 12 * ((14 - month) / 12) - 2;
        int d = (day + x + (31 * m) / 12) % 7;
        return d;
    }

    static int Week(int day, int month, int year) {
        int time[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
        year -= (month < 3) ? 1 : 0;
        return (year + year / 4 - year / 100 + year / 400 + time[month - 1] + day) % 7;
    }

    // this program will control or output whether it is or inst a leap year
    public static boolean isitLeapYear(int year) {
        if ((year % 4 == 0) && (year % 100 != 0))
            return true;
        if (year % 400 == 0)
            return true;
        return false;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter year:  ");
        int year = in.nextInt();
        System.out.print("Enter month:  ");
        int month = in.nextInt();
        System.out.print("Enter date:  ");
        int day = in.nextInt();
        // months[i] = name of month i
        String[] months = { "", // leave empty so that months[1] = "January"
                "January", "Febuary", "March", "April", "May", "June", "July", "August", "September", "Ocotber",
                "November", "December" };
        String[] Weeks = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

        int[] days = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        boolean leap = isitLeapYear(year);
        if (leap)
            System.out.println(String.format("%d is a leap year.", year));
        else
            System.out.println(String.format("%d isn't a leap year.", year));

        // this will check for leap year
        if (month == 2 && isitLeapYear(year))
            days[month] = 29;
        int weekDay = Week(day, month, year);
        System.out.println(String.format("%d/%d/%d was a %s", month, day, year, Weeks[weekDay]));
        System.out.println(String.format("The month %s has %d days", months[month], days[month]));
        // print calendar header
        System.out.println(String.format("The calendar for %s %d", months[month], year));
        // System.out.println("   " + months[month] + " " + year);
        System.out.println(" S  M Tu  W Th  F  S");


        int d = day(month, 1, year);

        // print the calendar

        for (int i = 0; i < d; i++)
            System.out.print("   ");
        for (int i = 1; i <= days[month]; i++) {
            System.out.printf("%2d ", i);
            if (((i + d) % 7 == 0) || (i == days[month]))
                System.out.println();
        }
        System.out.println(String.format("The date entered is:             %d/%d/%d", month, day, year));

        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss aa");
        Date currentTime = new Date();
        System.out.println("Today's current date and time:   " + df.format(currentTime));

        // Getting the current day
        LocalDate currentdate = LocalDate.now();
        int currentDay = currentdate.getDayOfMonth();
        // Getting the current month
        int currentMonth = currentdate.getMonthValue();

        // getting the current year
        int currentYear = currentdate.getYear();
        SimpleDateFormat myFormat = new SimpleDateFormat("dd MM yyyy");
        String dateBeforeString = String.valueOf(day);
        dateBeforeString += " ";
        dateBeforeString += month;
        dateBeforeString += " ";
        dateBeforeString += year;

        String dateAfterString = String.valueOf(currentDay);
        dateAfterString += " ";
        dateAfterString += currentMonth;
        dateAfterString += " ";
        dateAfterString += currentYear;
        long daysBetween = 0;

        try {
            Date dateBefore = (Date) myFormat.parse(dateBeforeString);
            Date dateAfter = (Date) myFormat.parse(dateAfterString);
            long difference = dateAfter.getTime() - dateBefore.getTime();
            daysBetween = (difference / (1000*60*60*24));
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(currentYear > year)
            System.out.println("The date entered is before the current date.");
        else if(currentYear == year && currentMonth > month)
            System.out.println("The date entered is before the current date.");
        else if(currentYear == year && currentMonth == month && currentDay > day)
            System.out.println("The date entered is before the current date.");
        else
            System.out.println("The date entered is before the current date.");
        System.out.println(String.format("The number of days between the entered date and the current date is: %d",daysBetween));
    }
}