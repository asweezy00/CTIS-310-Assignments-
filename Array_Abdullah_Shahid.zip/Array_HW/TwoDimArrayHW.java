// Import necessary packages

import java.util.*;
import java.lang.*;
import java.io.*;

class TwoDimArrayHW
{
   // Function to print the array
   static void printArray(int arr[][]) {
       System.out.println("Printing the array:");
      
       // Get the total number of rows and columns as that may vary if we take a 2D array of different dimension
       // We'll be finding total number of rows and columns in each function and then use them in our logic
       int total_rows = arr.length;
       int total_columns = arr[0].length;
      
       // Simply iterating through them all and printing
       for(int i=0;i<total_rows;i++) {
           for(int j=0;j<total_columns;j++)
               System.out.print("[" + i + "][" + j + "] = " + arr[i][j] + " ");
           System.out.println();
       }
       System.out.println();
   }
  
   static void printArray(double arr[][]) {
       // Same function as above, I'll be explaining only the int argument functions
       // The functions with double argument work the same way
       int total_rows = arr.length;
       int total_columns = arr[0].length;
       for(int i=0;i<total_rows;i++) {
           for(int j=0;j<total_columns;j++)
               System.out.print("[" + i + "][" + j + "] = " + arr[i][j]);
           System.out.println();
       }
   }
  
   static double getTotal(double arr[][]) {
       double total = 0.0;
       int total_rows = arr.length;
       int total_columns = arr[0].length;
       for(int i=0;i<total_rows;i++) {
           for(int j=0;j<total_columns;j++)
               total += arr[i][j];
       }
       return total;
   }
  
   static int getTotal(int arr[][]) {
      
       // Initialize total variable with 0
       int total = 0;
       int total_rows = arr.length;
       int total_columns = arr[0].length;
       // Iterate through allt he elements and keep on adding
       for(int i=0;i<total_rows;i++) {
           for(int j=0;j<total_columns;j++)
               total += arr[i][j];
       }
       return total;
   }
  
   static double getAverage(double arr[][]) {
       int total_rows = arr.length;
       int total_columns = arr[0].length;
       double average = getTotal(arr)/(total_rows*total_columns);
       return average;
   }
  
   static int getAverage(int arr[][]) {
       int total_rows = arr.length;
       int total_columns = arr[0].length;
      
       // For average first we fin the total using getTotal() function and then dicide it by (row*column)
       int average = getTotal(arr)/(total_rows*total_columns);
       return average;
   }
  
   static double getRowTotal(double arr[][], int row) {
       double row_total = 0.0;
       int total_columns = arr[0].length;
       for(int j=0;j<total_columns;j++) {
           row_total += arr[row][j];
       }
       return row_total;
   }
  
   static int getRowTotal(int arr[][], int row) {
       int row_total = 0;
       int total_columns = arr[0].length;
      
       // Iterate throuigh all the columns of the given row and keep on adding them
       for(int j=0;j<total_columns;j++) {
           row_total += arr[row][j];
       }
       return row_total;
   }
  
   static double getColumnTotal(double arr[][], int column) {
       double col_total = 0.0;
       int total_rows = arr.length;
       for(int i=0;i<total_rows;i++) {
           col_total += arr[i][column];
       }
       return col_total;
   }
  
   static int getColumnTotal(int arr[][], int column) {
       int col_total = 0;
       int total_rows = arr.length;
      
       // Iterate through all the rows of the given column and keep on adding them
       for(int i=0;i<total_rows;i++) {
           col_total += arr[i][column];
       }
       return col_total;
   }
  
   static double getHighestInRow(double arr[][], int row) {
       double highest = Double.MIN_VALUE;
       int total_columns = arr[0].length;
       for(int j=0;j<total_columns;j++) {
           if(arr[row][j] > highest)
               highest = arr[row][j];
       }
       return highest;
   }
  
   static int getHighestInRow(int arr[][], int row) {
       // Initialize highest variable with the minimum value possible
       int highest = Integer.MIN_VALUE;
       int total_columns = arr[0].length;
      
       // For each element in the row, check if that element is greater than highest, if yes, update it
       for(int j=0;j<total_columns;j++) {
           if(arr[row][j] > highest)
               highest = arr[row][j];
       }
       return highest;
   }
  
   static double getLowestInRow(double arr[][], int row) {
      
       double lowest = Double.MAX_VALUE;
       int total_columns = arr[0].length;
       for(int j=0;j<total_columns;j++) {
           if(arr[row][j] < lowest)
               lowest = arr[row][j];
       }
       return lowest;
   }
  
   static int getLowestInRow(int arr[][], int row) {
      
       // Same logic as used in getHighestInRow
      
       int lowest = Integer.MAX_VALUE;
       int total_columns = arr[0].length;
       for(int j=0;j<total_columns;j++) {
           if(arr[row][j] < lowest)
               lowest = arr[row][j];
       }
       return lowest;
   }
  
   static int[][] flipArrayHorizontally(int[][] original) {
      
       //Approach: To flip array horizontally, go through each column, and for each column copy the opposite row
       //elements, e.g.- in first we copy the last, in second we copy the second last and so on
      
       int total_rows = original.length;
       int total_columns = original[0].length;
       System.out.println("Flipping the array Horizontally:");
       int[][] h_flipped = new int[total_rows][total_columns];
       for(int col = 0;col<total_columns;col++) {
           // The 'row' denotes the rows of our original array,
           // and 'flipped_row' denotes the row of our flipped array
           for(int row = 0, flipped_row = total_rows-1;row<total_rows;row++, flipped_row--) {
               h_flipped[flipped_row][col] = original[row][col];
           }
       }
       return h_flipped;
   }
  
   static int[][] flipArrayVertically(int[][] original) {
      
       //Approach: To flip array vertically, go through each row for each row copy the opposite column
       //elements, e.g.- in first we copy the last, in second we copy the second last and so on
      
       int total_rows = original.length;
       int total_columns = original[0].length;
       System.out.println("Flipping the array Vertically:");
       int[][] v_flipped = new int[total_rows][total_columns];
       for(int row = 0;row<total_rows;row++) {
           // The 'col' denotes the columns of our original array,
           // and 'flipped_col' denotes the column of our flipped array
           for(int col = 0, flipped_col = total_columns-1;col<total_columns;col++, flipped_col--) {
               v_flipped[row][flipped_col] = original[row][col];
           }
       }
       return v_flipped;
   }
  
   static int[][] reverseArray(int[][] original) {
      
       //Approach : Simple approach, just traverse through the array and copy every element in opposite manner
       // e.g. - in the new array, copy [0][0] in [2][4], [0][1] in [2][3], [0][2] in [2][2] and so on...
      
       int total_rows = original.length;
       int total_columns = original[0].length;
       System.out.println("Reversing the array:");
       int[][] reverse = new int[total_rows][total_columns];
       for(int orig_row = total_rows-1, rev_row = 0; orig_row>=0;orig_row--, rev_row++) {
           for(int orig_col = total_columns-1, rev_col = 0; orig_col >= 0; orig_col--, rev_col++) {
               reverse[rev_row][rev_col] = original[orig_row][orig_col];
           }
       }
       return reverse;
   }
  
   static int[][] transposeArray(int[][] original) {
      
       // Approach: Very easy approach, you can just replace arr[i][j] element with arr[j][i] element and it
       // will transpose
      
       int total_rows = original.length;
       int total_columns = original[0].length;
       System.out.println("Transposing the array:");
       int[][] trans = new int[total_columns][total_rows];
       for(int row=0;row<total_rows;row++) {
           for(int col=0;col<total_columns;col++) {
               trans[col][row] = original[row][col];
           }
       }
       return trans;
   }
  
   static int[][] reverseTransposeArray(int[][] original) {
      
       // First transpose the array using the transposeArray approach, and then reverse it using reverArray approach
      
       int total_rows = original.length;
       int total_columns = original[0].length;
       System.out.println("Reversing and transposing the array:");
       int[][] trans = new int[total_columns][total_rows];
       for(int row=0;row<total_rows;row++) {
           for(int col=0;col<total_columns;col++) {
               trans[col][row] = original[row][col];
           }
       }
       int[][] rev_trans = new int[total_columns][total_rows];
       for(int trans_row = total_columns-1, rev_trans_row = 0; trans_row>=0;trans_row--, rev_trans_row++) {
           for(int trans_col = total_rows-1, rev_trans_col = 0; trans_col >= 0; trans_col--, rev_trans_col++) {
               rev_trans[rev_trans_row][rev_trans_col] = trans[trans_row][trans_col];
           }
       }
       return rev_trans;
   }
  
   public static void main (String[] args) throws java.lang.Exception
   {
      
       int twoDimHW[][] = new int[3][5];
       Scanner sc = new Scanner(System.in);
       for(int i=0;i<3;i++) {
           for(int j=0;j<5;j++) {
               System.out.print("Please enter an integer value for twoDimHW[" + i + "][" +j +"]: ");
               twoDimHW[i][j] = sc.nextInt();
           }
       }
       printArray(twoDimHW);
      
       int[][] numberReverse = new int[3][5];
       numberReverse = flipArrayHorizontally(twoDimHW);
       printArray(numberReverse);
      
       int[][] flipArrVer = new int[3][5];
       flipArrVer = flipArrayVertically(twoDimHW);
       printArray(flipArrVer);
      
       int[][] reverseArr = new int[3][5];
       reverseArr = reverseArray(twoDimHW);
       printArray(reverseArr);
      
       int[][] transpArr = new int[5][3];
       transpArr = transposeArray(twoDimHW);
       printArray(transpArr);
      
       int[][] reverseTranspArr = new int[5][3];
       reverseTranspArr = reverseTransposeArray(twoDimHW);
       printArray(reverseTranspArr);
      
       printArray(twoDimHW);
      
       System.out.println("Total of twoDimHW: "+ getTotal(twoDimHW));
       System.out.println("Average of twoDimHW: "+ getAverage(twoDimHW));
       System.out.println("Total of row 0 of twoDimHW: "+ getRowTotal(twoDimHW, 0));
       System.out.println("Total of row 1 of twoDimHW: "+ getRowTotal(twoDimHW, 1));
       System.out.println("Total of col 0 of twoDimHW: "+ getColumnTotal(twoDimHW, 0));
       System.out.println("Total of col 2 of twoDimHW: "+ getColumnTotal(twoDimHW, 2));
       System.out.println("Highest in row 0 of twoDimHW:: "+ getHighestInRow(twoDimHW, 0));
       System.out.println("Highest in row 1 of twoDimHW: "+ getHighestInRow(twoDimHW, 1));
       System.out.println("Lowest in row 0 of twoDimHW: "+ getLowestInRow(twoDimHW, 0));
       System.out.println("Lowest in row 1 of twoDimHW: "+ getLowestInRow(twoDimHW, 1));
      
   }
}