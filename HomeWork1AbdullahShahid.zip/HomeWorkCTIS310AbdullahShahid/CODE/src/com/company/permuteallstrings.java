package com.company;

// Abdullah Shahid

import java.util.Scanner;

public class permuteallstrings {
    public static void main (String[] args){
        System.out.println("Enter a String to permute: ");
        Scanner scnr = new Scanner(System.in); // scanner added to take input from user
        String f = scnr.next();
        int n = f.length();
        permuteallstrings permute = new permuteallstrings(); // calculate permuations for all strings
        permute.recur(f, 0, n-1);

    }
    //the code below will give us our recursive function
    private void recur (String str, int b , int e) { // e and b will determine start and end of string
        if (b == e) { // (check if we reached end of string) base case if b equals e then print string meaning that all letters have been swapped and we have reached end __> print
            System.out.println(str); // then print it
        } else { // if not then continue and look to swap until n<=e
            for (int n = b; n <= e; n++) { // look to swap first character until last
                String swapped = this.swapping(str, b, n); // each recursive cycle moves one character to the right
                this.recur(swapped, b + 1, e); // start with next character and keep swapping until end
            }
        }
    }

    private String swapping(String str,int n,int k)
        {

        char swp; // will use later for swapping
        char[] charArray = str.toCharArray(); // convert string to character array
        swp = charArray[n]; // do character swap with index n
        charArray [n] = charArray[k]; // swap character n with character k
        charArray[k] = swp; // swap character k with swp or original
        return String.valueOf(charArray); // convert character array to regular string



    }

}
